# hoppin-magento-payment-method
Magento module to add Hoppin payment method
