<?php

/**
* Our test CC module adapter
*/
class Mage_Hoppin_Model_PaymentMethod extends Mage_Payment_Model_Method_Abstract
{
    protected $_code  = 'hoppin';
    protected $_canUseInternal = true;
    //protected $_formBlockType = 'payment/form_checkmo';
    //protected $_infoBlockType = 'payment/info_cod';

    /**
     * Assign data to info model instance
     *
     * @param   mixed $data
     * @return  Mage_Payment_Model_Method_Checkmo
     */
    public function isAvailable($quote=null)
	    {
	        // $shipping = Mage::getSingleton('checkout/session')->getQuote()->getShippingAddress()->getShippingMethod();

	        // if (eregi("freeshipping_freeshipping", $shipping)) {
	        //     return true;
	        // }
	        // return false;
	        return true;
	    }

}
