<?php
/*
* 2017 - HOPPIN - Swipe technologies
*/

if (!defined('_PS_VERSION_'))
        exit;

class Hoppin extends PaymentModule
{
        protected $_html = '';
        protected $_postErrors = array();

        public $details;
        public $owner;
        public $address;
        public $extra_mail_vars;
        public function __construct()
        {
			$this->name = 'hoppin';
			$this->tab = 'payments_gateways';
			$this->version = '1.2.0';
			$this->author = 'Swipe technologies';

			$this->is_eu_compatible = 1;

			$this->currencies = true;
			$this->currencies_mode = 'checkbox';

			$this->bootstrap = true;
			parent::__construct();

			$this->displayName = $this->l('HOPPIN Payments');
			$this->description = $this->l('Accept payments from HOPPIN');
			$this->confirmUninstall = $this->l('Are you sure about removing HOPPIN module?');
			$this->ps_versions_compliancy = array('min' => '1.6', 'max' => '1.6.99.99');

        }

        public function install()
        {

			$this->installOrderState();
			return (parent::install());

        }

        public function uninstall()
        {
            return true;

        }

        public function installOrderState() {

            $order_state_id = Configuration::get('HOPPIN_SUCCESS_ORDER_STATE');

            // If the state does not exist, we create it.
            if ($order_state_id) {

                $OrderState = new OrderState($order_state_id);

            } else {

                $OrderState = new OrderState();

            }

            $OrderState->name = array_fill(0,10,'HOPPIN payment accepted');
            $OrderState->send_email = 0;
            $OrderState->invoice = 0;
            $OrderState->color = "#ea6044";
            $OrderState->unremovable = true;
            $OrderState->logable = 1;
            $OrderState->paid = 1;
            $OrderState->shipped = 0;


            if ($order_state_id) {

                $OrderState->save();

            } else {

                $OrderState->add();

            }

            Configuration::updateValue('HOPPIN_SUCCESS_ORDER_STATE',$OrderState->id);

            copy(dirname(__FILE__).'/logo.gif',dirname(__FILE__).'/../../img/os'.$OrderState->id.'.gif');

			copy(dirname(__FILE__).'/logo.gif',dirname(__FILE__).'/../../img/tmp/order_state_mini_'.$OrderState->id.'.gif');

            return true;

       }

   public function validateOrder($id_cart, $id_order_state, $amount_paid, $payment_method = 'Unknown', $message = null, $extra_vars = array(), $currency_special = null, $dont_touch_amount = false, $secure_key = false, Shop $shop = null) {

		if (strtolower($this->name) ==  strtolower($payment_method)) {

			$id_order_state = Configuration::get('HOPPIN_SUCCESS_ORDER_STATE');

		}

		return parent::validateOrder($id_cart, $id_order_state, $amount_paid, $payment_method, $message, $extra_vars, $currency_special, $dont_touch_amount, $secure_key, $shop);

   }

}
